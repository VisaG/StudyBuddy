﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace StudyBuddy
{
	public partial class MyPage : ContentPage
	{
		public MyPage()
		{
			InitializeComponent();
		}
	}
}
