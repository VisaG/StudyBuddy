﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace StudyBuddy.Views
{
	public partial class NotificationsPage : ContentPage
	{
		public NotificationsPage()
		{
			InitializeComponent();
		}
	}
}
