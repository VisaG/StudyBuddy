using System;
using System.Collections.Generic;

using Xamarin.Forms;


using StudyBuddy.Models;


namespace StudyBuddy.Views
{
	public partial class ProfilePage : ContentPage
	{

	
		public ProfilePage()
		{
			InitializeComponent();



		}


	}
}
