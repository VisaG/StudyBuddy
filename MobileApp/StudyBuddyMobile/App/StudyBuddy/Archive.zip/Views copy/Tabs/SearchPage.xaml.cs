using System;
using System.Collections.Generic;

using Xamarin.Forms;

using StudyBuddy.Models;

namespace StudyBuddy.Views
{
	public partial class SearchPage : ContentPage
	{


		Group groupFound;

		public SearchPage()
		{
			InitializeComponent();
		}


		void OnSearchBarTextChanged(object sender, TextChangedEventArgs args)
		{

		}

		void OnSwitchAvailToggled(object sender, EventArgs args)
		{


		}

		void OnSwitchCourseToggled(object sender, EventArgs args)
		{
		}


		void OnSearchBarButtonPressed(object sender, EventArgs args)
		{
			
		

		}

		void createGroupSearchStack()
		{
		}

		void createStudentSearchStack(int groupId)
		{
			

		}
	}
}
